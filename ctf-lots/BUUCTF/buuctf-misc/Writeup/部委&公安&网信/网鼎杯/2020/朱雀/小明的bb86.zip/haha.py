#!/usr/bin/python3
import sys
from random import *
from secret import flag

HACK=False
NUMS=20
rd2=lambda:randint(0,1)
getBase=lambda lens=NUMS:[rd2() for i in range(lens)]
getBins=lambda strings:[list(map(int,list(bin(ord(i))[2:].rjust(8,'0')))) for i in strings]

def inits():
	while True:
		a_base,b_base=getBase(),getBase()
		check=[1 if a_base[i] == b_base[i] else 0 for i in range(NUMS)]
		if sum(check) > 8:
			break
	print('check ',check)
	return a_base,b_base,check

def hack(hack_base,a_base,data):
	res=[]
	assert len(hack_base) == len(a_base) == len(data)
	for i in range(len(a_base)):
		if hack_base[i] != a_base[i]:
			data[i]=rd2()
	return data

def qb(x,y):
	assert len(x)==len(y)
	tmp=[['0','1'],['o','l']]
	return [tmp[x[i]][y[i]] for i in range(len(x))]

def comm(a_base,b_base,check,hack_base=None):
	bf,index=getBins(flag),0
	for i in bf:
		x=0
		m=[]
		for j in check:
			if j and x<8:
				m.append(i[x])
				x+=1
			else:
				m.append(rd2())
		enc=qb(a_base,m)
		if HACK:
			hack_m=hack(hack_base,a_base,m)
			hack_enc=qb(hack_base,hack_m)
			print ('hack->',''.join(hack_enc))
		x=0
		c=''
		for j in range(NUMS):
			if check[j] and x<8:
				c+=str(m[j])
				x+=1
		if chr(int(c,2)) == flag[index]:
			print("Received the %d char successfully."%index)
			index+=1
		else:
			print("Received the %d char error, maybe have hack"%index)
			break

if __name__ == '__main__':
	a_base,b_base,check=inits()
	try:
		print('Do you want to monitor communication? (y/n)',end=' ')
		if input()[0] == 'y':
			sys.stdout.flush()
			hack_base=list(map(int,input("Please input your base(use ',' to split): ").split(',')))
			assert len(hack_base)==NUMS
			for i in hack_base:
				assert i in [0,1]
			HACK=True
		else:
			hack_base=None
			print("Good boy~")
	except:
		print("Oh~~ bad boooooooooy")
		sys.exit(0)
	print('hackse',hack_base)
	comm(a_base,b_base,check,hack_base)
